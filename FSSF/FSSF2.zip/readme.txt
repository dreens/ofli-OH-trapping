FSSF2 Fourier Series Surface Fitter ver.0.9b
(c) Miltiades Salvanos 2003

Archive contains FSSF2 gui and kernel .m files and sample data workspace.
run fssf.m with data in current workspace

GPL-OS software. please credit author in redistributions
writedxf.m contains external code retrieved from MatlabCentral-credit its respective author

